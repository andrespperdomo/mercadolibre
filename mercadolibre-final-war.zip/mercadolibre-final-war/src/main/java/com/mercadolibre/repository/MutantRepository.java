package com.mercadolibre.repository;


import org.springframework.data.repository.CrudRepository;

import com.mercadolibre.entity.Mutant;


public interface MutantRepository extends CrudRepository<Mutant, Integer>{



}
