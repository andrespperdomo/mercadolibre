package com.mercadolibre.dto;

import lombok.Data;

@Data
public class MutantDTO {

	String [] dna;
}
